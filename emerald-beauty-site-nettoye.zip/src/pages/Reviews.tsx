import { ExternalLink, Star } from "lucide-react";
import { business } from "@/config/business";
import { images } from "@/config/images";
import { useReveal, useSeo } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { Eyebrow, PageHero, SectionTitle } from "@/components/shared";
import { CtaBand, GoogleG, ReviewsBlock } from "@/components/sections";

export default function Reviews() {
  useSeo("Avis clients — Emerald Beauty and more", "Note Google 5,0/5 : avis publics des clientes d'Emerald Beauty and more à Delmas 40B, Port-au-Prince.");
  useReveal();
  return (
    <>
      <PageHero
        eyebrow="Avis clients"
        title={<>5,0 <em className="text-gold-300">sur Google</em></>}
        intro="Les avis affichés ici sont les avis publics de la fiche Google du salon, reproduits tels quels."
        img={images.makeup}
      />
      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <ReviewsBlock full />
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 sm:px-8">
        <div className="reveal grid items-center gap-10 rounded-[2rem] bg-cream-100 p-8 sm:p-12 lg:grid-cols-2">
          <div>
            <Eyebrow>Votre avis compte</Eyebrow>
            <SectionTitle className="!text-4xl">Vous êtes venue au salon ?</SectionTitle>
            <p className="mt-4 text-emerald-950/70">
              Partagez votre expérience sur Google : vos retours aident d'autres clientes à découvrir {business.name}.
            </p>
          </div>
          <div className="flex flex-col items-start gap-5 lg:items-end">
            <div className="flex gap-2" aria-hidden="true">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="size-9 fill-gold-400 text-gold-400" />
              ))}
            </div>
            <Button asChild size="lg">
              <a href={business.google.mapsUrl} target="_blank" rel="noopener noreferrer">
                <GoogleG /> Laisser un avis sur Google <ExternalLink />
              </a>
            </Button>
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
