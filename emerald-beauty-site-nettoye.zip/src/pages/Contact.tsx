import { Clock, MapPin, Navigation, Mail } from "lucide-react";
import { business } from "@/config/business";
import { images } from "@/config/images";
import { useReveal, useSeo } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { BookingForm } from "@/components/BookingForm";
import { CallButton, Eyebrow, PageHero, Photo, WhatsAppButton, useNotConfigured } from "@/components/shared";
import { LocationBlock } from "@/components/sections";

export default function Contact({ params }: { params: URLSearchParams }) {
  useSeo(
    "Contact & rendez-vous — Emerald Beauty and more, Delmas 40B",
    "Demandez un rendez-vous chez Emerald Beauty and more, 7 Rue Crepsac, Delmas 40B, Port-au-Prince. Formulaire, WhatsApp et itinéraire."
  );
  useReveal();
  const notConfigured = useNotConfigured();
  const service = params.get("service") ?? "";

  return (
    <>
      <PageHero
        eyebrow="Contact & rendez-vous"
        title={<>Réservez votre <em className="text-gold-300">moment</em></>}
        intro="Remplissez le formulaire : le salon reçoit votre demande et vous confirme le créneau."
        img={images.pedicureChair}
      />

      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="reveal rounded-[2rem] bg-white p-6 shadow-xl shadow-emerald-950/5 ring-1 ring-emerald-900/8 sm:p-10 lg:col-span-7">
            <Eyebrow>Demande de rendez-vous</Eyebrow>
            <h2 className="mb-8 font-display text-4xl">Votre demande</h2>
            <BookingForm defaultService={service} />
          </div>

          <aside className="space-y-6 lg:col-span-5">
            <div className="reveal rounded-[2rem] bg-emerald-950 p-8 text-cream-50">
              <h2 className="font-display text-3xl">Contact direct</h2>
              <p className="mt-2 text-sm text-cream-50/65">Préférez-vous écrire ou appeler ?</p>
              <div className="mt-6 grid gap-3">
                <WhatsAppButton size="lg" className="w-full" />
                <CallButton variant="outlineLight" size="lg" className="w-full" />
                <Button
                  variant="outlineLight"
                  size="lg"
                  className="w-full"
                  onClick={() =>
                    business.email
                      ? (window.location.href = `mailto:${business.email}`)
                      : notConfigured({ title: "E-mail — à configurer", detail: "Aucune adresse e-mail n'est indiquée sur la fiche Google." })
                  }
                >
                  <Mail /> E-mail
                </Button>
              </div>
            </div>
            <div className="reveal space-y-5 rounded-[2rem] bg-cream-100 p-8">
              <div className="flex gap-4">
                <MapPin className="size-5 shrink-0 text-gold-600" />
                <div>
                  <p className="font-semibold">Adresse</p>
                  <address className="not-italic text-sm text-emerald-950/70">{business.address.full}</address>
                </div>
              </div>
              <div className="flex gap-4">
                <Clock className="size-5 shrink-0 text-gold-600" />
                <div>
                  <p className="font-semibold">Horaires</p>
                  <p className="text-sm text-emerald-950/70">{business.hours.known} · détail à confirmer</p>
                </div>
              </div>
              <Button asChild variant="outline" className="w-full">
                <a href={business.google.directionsUrl} target="_blank" rel="noopener noreferrer"><Navigation /> Obtenir l'itinéraire</a>
              </Button>
            </div>
            <Photo img={images.heroSalon} className="reveal aspect-[16/10] rounded-[2rem] rounded-br-[4rem]" />
          </aside>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 sm:px-8">
        <div className="reveal"><LocationBlock /></div>
      </section>
    </>
  );
}
