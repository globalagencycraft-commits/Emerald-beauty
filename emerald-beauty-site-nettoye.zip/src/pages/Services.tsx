import { useEffect, useState } from "react";
import { ArrowRight, Tag } from "lucide-react";
import { business, categories, services, type ServiceCategoryId } from "@/config/business";
import { categoryCover, images } from "@/config/images";
import { Link, useReveal, useSeo } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/misc";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Eyebrow, PageHero, Photo, SectionTitle } from "@/components/shared";
import { CtaBand } from "@/components/sections";

type Tab = ServiceCategoryId | "all";

export default function Services({ params }: { params: URLSearchParams }) {
  useSeo(
    "Prestations — Emerald Beauty and more | Coiffure, tresses, ongles, maquillage",
    "Balayage, brushing, box braids, dreadlocks, manucure, ongles acryliques, pédicure, extensions de cils, sourcils, maquillage et services mariée à Delmas 40B."
  );
  const initial = (params.get("cat") as Tab) || "all";
  const [tab, setTab] = useState<Tab>(initial);
  useEffect(() => setTab(initial), [initial]);
  useReveal(tab);

  const list = (cat: Tab) => (cat === "all" ? services : services.filter((s) => s.category === cat));

  return (
    <>
      <PageHero
        eyebrow="Catalogue"
        title={<>Nos <em className="text-gold-300">prestations</em></>}
        intro={`Les ${services.length} prestations proposées par ${business.name}, organisées par univers. Tarifs communiqués sur demande.`}
        img={images.braids}
      />

      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <Tabs value={tab} onValueChange={(v) => setTab(v as Tab)}>
          <TabsList aria-label="Filtrer les prestations par univers" className="w-full sm:w-fit">
            <TabsTrigger value="all">Tout ({services.length})</TabsTrigger>
            {categories.map((c) => (
              <TabsTrigger key={c.id} value={c.id}>{c.label}</TabsTrigger>
            ))}
          </TabsList>

          {(["all", ...categories.map((c) => c.id)] as Tab[]).map((cat) => {
            const meta = categories.find((c) => c.id === cat);
            const cover = cat === "all" ? images.tools : categoryCover[cat];
            return (
              <TabsContent key={cat} value={cat}>
                <div className="grid gap-10 lg:grid-cols-12">
                  <aside className="lg:col-span-4">
                    <div className="lg:sticky lg:top-28">
                      <Photo img={cover} className="aspect-[4/5] rounded-[2rem] rounded-tl-[5rem]" />
                      <div className="mt-6">
                        <h2 className="font-display text-3xl">{meta?.label ?? "Toutes les prestations"}</h2>
                        <p className="mt-1 text-sm text-emerald-950/60">{meta?.tagline ?? "Beauté des cheveux, des mains, des pieds et du regard."}</p>
                      </div>
                    </div>
                  </aside>
                  <ul className="divide-y divide-emerald-900/10 lg:col-span-8">
                    {list(cat).map((s, i) => (
                      <li key={s.name} className="reveal group flex flex-col gap-4 py-7 sm:flex-row sm:items-center sm:justify-between" style={{ transitionDelay: `${Math.min(i, 6) * 50}ms` }}>
                        <div className="flex gap-5">
                          <span className="pt-1 font-display text-lg text-gold-600">{String(i + 1).padStart(2, "0")}</span>
                          <div>
                            <h3 className="font-display text-2xl text-emerald-950 sm:text-3xl">{s.name}</h3>
                            <p className="mt-1 max-w-md text-sm text-emerald-950/65">{s.description}</p>
                            <div className="mt-3 flex flex-wrap gap-2">
                              {cat === "all" && <Badge>{categories.find((c) => c.id === s.category)?.label}</Badge>}
                              <Badge variant="gold"><Tag className="size-3" /> Tarif sur demande</Badge>
                            </div>
                          </div>
                        </div>
                        <Button asChild variant="outline" size="sm" className="self-start sm:self-center group-hover:bg-emerald-900 group-hover:text-cream-50">
                          <Link to={`/contact?service=${encodeURIComponent(s.name)}`} aria-label={`Réserver : ${s.name}`}>Réserver <ArrowRight /></Link>
                        </Button>
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>
            );
          })}
        </Tabs>
      </section>

      <section className="bg-cream-100 py-20">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Eyebrow>Questions fréquentes</Eyebrow>
            <SectionTitle>Bon à savoir</SectionTitle>
            <Photo img={images.brows} className="reveal mt-8 hidden aspect-[4/3] rounded-[2rem] rounded-tl-[4rem] lg:block" />
          </div>
          <Accordion type="single" collapsible className="lg:col-span-8">
            {[
              { q: "Quels sont les tarifs ?", a: "Les tarifs ne sont pas encore publiés en ligne. Envoyez une demande via le formulaire ou WhatsApp en précisant la prestation souhaitée : le salon vous communiquera le prix." },
              { q: "Comment prendre rendez-vous ?", a: "Utilisez la page Contact pour envoyer une demande de rendez-vous (prestation, date, moment préféré). Le salon vous recontacte pour confirmer le créneau." },
              { q: "Où se trouve le salon ?", a: `${business.address.full}. Un bouton « Itinéraire » ouvre directement Google Maps.` },
              { q: "Quels sont les horaires ?", a: "D'après Google, le salon ferme à 17 h. Les jours et heures d'ouverture détaillés seront affichés ici après confirmation." },
              { q: "Proposez-vous des services pour les mariées ?", a: "Oui, les services mariée font partie des prestations listées. Contactez le salon pour composer votre mise en beauté du jour J." },
            ].map((f) => (
              <AccordionItem key={f.q} value={f.q}>
                <AccordionTrigger className="text-lg">{f.q}</AccordionTrigger>
                <AccordionContent className="text-base">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      <div className="pt-24"><CtaBand /></div>
    </>
  );
}
