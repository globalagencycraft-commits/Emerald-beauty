import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, ImagePlus, Expand } from "lucide-react";
import { categories } from "@/config/business";
import { galleryImages, images, realPhotosToCollect } from "@/config/images";
import { useReveal, useSeo } from "@/lib/router";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Eyebrow, PageHero, Photo, SectionTitle } from "@/components/shared";
import { CtaBand } from "@/components/sections";
import { cn } from "@/utils/cn";

const FILTERS = [{ id: "all", label: "Tout" }, ...categories.map((c) => ({ id: c.id, label: c.label })), { id: "salon", label: "Salon" }];

export default function Gallery() {
  useSeo("Galerie — Emerald Beauty and more", "Galerie photo : coiffure, tresses, locs, ongles, regard, maquillage et mariage.");
  const [filter, setFilter] = useState("all");
  const [index, setIndex] = useState<number | null>(null);
  const items = useMemo(() => (filter === "all" ? galleryImages : galleryImages.filter((g) => g.category === filter)), [filter]);
  useReveal(filter);

  const go = useCallback((d: number) => setIndex((i) => (i === null ? i : (i + d + items.length) % items.length)), [items.length]);
  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, go]);

  const current = index !== null ? items[index] : null;

  return (
    <>
      <PageHero
        eyebrow="Galerie"
        title={<>L'art du <em className="text-gold-300">détail</em></>}
        intro="Coiffure, tresses, ongles, regard, maquillage et mariage : un aperçu de l'univers Emerald Beauty."
        img={images.french}
      />

      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div role="group" aria-label="Filtrer la galerie" className="no-scrollbar mb-10 flex gap-2 overflow-x-auto">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              aria-pressed={filter === f.id}
              onClick={() => setFilter(f.id)}
              className={cn(
                "shrink-0 cursor-pointer rounded-full px-5 py-2.5 text-sm font-medium ring-1 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400",
                filter === f.id ? "bg-emerald-900 text-cream-50 ring-emerald-900" : "bg-white text-emerald-950/75 ring-emerald-900/10 hover:ring-emerald-900/30"
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="columns-2 gap-4 md:columns-3 lg:columns-4 [&>*]:mb-4">
          {items.map((img, i) => (
            <button
              key={img.src}
              type="button"
              onClick={() => setIndex(i)}
              className="reveal group relative block w-full cursor-zoom-in break-inside-avoid overflow-hidden rounded-[1.5rem] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400"
              aria-label={`Agrandir : ${img.alt}`}
            >
              <Photo img={img} className={img.tall ? "aspect-[3/4]" : "aspect-[4/3]"} />
              <span className="absolute right-3 top-3 flex size-9 items-center justify-center rounded-full bg-white/85 text-emerald-950 opacity-0 transition group-hover:opacity-100">
                <Expand className="size-4" />
              </span>
            </button>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 sm:px-8">
        <div className="reveal rounded-[2rem] border-2 border-dashed border-gold-500/40 bg-gold-400/5 p-8 sm:p-12">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <Eyebrow>Prochaine étape</Eyebrow>
              <SectionTitle className="!text-4xl">Vos vraies réalisations ici</SectionTitle>
              <p className="mt-4 text-emerald-950/70">
                Les photos déjà publiées sur la fiche Google du salon seront intégrées en priorité, avec votre accord :
              </p>
            </div>
            <ul className="space-y-3">
              {realPhotosToCollect.map((p) => (
                <li key={p} className="flex gap-3 rounded-2xl bg-white p-4 text-sm ring-1 ring-emerald-900/8">
                  <ImagePlus className="size-5 shrink-0 text-gold-600" /> {p}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <Dialog open={index !== null} onOpenChange={(o) => !o && setIndex(null)}>
        <DialogContent className="max-w-5xl bg-emerald-950 p-3 sm:p-4 [&>button:last-child]:right-5 [&>button:last-child]:top-5 [&>button:last-child]:bg-black/50 [&>button:last-child]:text-white" overlayClassName="bg-black/85">
          {current && (
            <>
              <DialogTitle className="sr-only">{current.alt}</DialogTitle>
              <DialogDescription className="sr-only">Image {index! + 1} sur {items.length}</DialogDescription>
              <img src={current.src.replace(/w=\d+/, "w=1600")} alt={current.alt} className="max-h-[78vh] w-full rounded-2xl object-contain" />
              <div className="flex items-center justify-between gap-4 px-2 pt-3 text-cream-50">
                <p className="text-xs text-cream-50/60">
                  {current.alt}
                </p>
                <div className="flex shrink-0 gap-2">
                  <button type="button" onClick={() => go(-1)} className="cursor-pointer rounded-full p-2 ring-1 ring-white/20 hover:bg-white/10" aria-label="Image précédente"><ChevronLeft className="size-5" /></button>
                  <button type="button" onClick={() => go(1)} className="cursor-pointer rounded-full p-2 ring-1 ring-white/20 hover:bg-white/10" aria-label="Image suivante"><ChevronRight className="size-5" /></button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <CtaBand />
    </>
  );
}
