import { ArrowRight, ArrowUpRight, CalendarHeart, MapPin, Sparkles, MessageSquareText, CheckCircle2, ListChecks } from "lucide-react";
import { business, categories, services } from "@/config/business";
import { categoryCover, images, galleryImages } from "@/config/images";
import { Link, useReveal, useSeo } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { Badge, Stars } from "@/components/ui/misc";
import { Eyebrow, Photo, SectionTitle, WhatsAppButton } from "@/components/shared";
import { CtaBand, GoogleG, LocationBlock, ReviewsBlock } from "@/components/sections";

export default function Home() {
  useSeo(
    "Emerald Beauty and more — Salon de beauté à Delmas 40B, Port-au-Prince",
    "Coiffure, box braids, tresses, locs, manucure, ongles acryliques, pédicure, cils, sourcils, maquillage et services mariée à Delmas 40B, Port-au-Prince."
  );
  useReveal();

  return (
    <>
      {/* ───── HERO ───── */}
      <section className="relative overflow-hidden bg-emerald-950 text-cream-50">
        <div className="grain absolute inset-0" />
        <div className="absolute -left-40 top-20 size-[36rem] rounded-full bg-emerald-700/25 blur-3xl" aria-hidden="true" />
        <div className="absolute -right-20 bottom-0 size-[28rem] rounded-full bg-gold-500/10 blur-3xl" aria-hidden="true" />

        <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 pt-36 sm:px-8 lg:grid-cols-12 lg:pb-28 lg:pt-44">
          <div className="lg:col-span-6 animate-fade-up">
            <a href={business.google.mapsUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 rounded-full bg-white/5 py-1.5 pl-1.5 pr-4 text-sm ring-1 ring-white/10 backdrop-blur transition hover:bg-white/10">
              <span className="flex size-7 items-center justify-center rounded-full bg-white"><GoogleG className="size-4" /></span>
              <Stars className="[&_svg]:size-3.5" />
              <span className="text-cream-50/80"><strong className="text-cream-50">5,0</strong> · {business.google.reviewCount} avis</span>
            </a>
            <h1 className="mt-8 text-balance font-display text-[3.4rem] font-medium leading-[0.95] sm:text-7xl lg:text-[5.5rem]">
              Votre beauté,
              <span className="block italic text-gold-300">sublimée</span>
              <span className="block">à Delmas.</span>
            </h1>
            <p className="mt-7 max-w-lg text-lg leading-relaxed text-cream-50/70">
              Coiffure, tresses & locs, ongles, regard, maquillage et services mariée — réunis dans un même salon à
              Port-au-Prince.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Button asChild variant="gold" size="lg"><Link to="/contact"><CalendarHeart /> Prendre rendez-vous</Link></Button>
              <Button asChild variant="outlineLight" size="lg"><Link to="/prestations">Voir les prestations <ArrowRight /></Link></Button>
            </div>
            <p className="mt-10 flex items-center gap-2 text-sm text-cream-50/55">
              <MapPin className="size-4 text-gold-300" /> {business.address.full}
            </p>
          </div>

          {/* Collage */}
          <div className="relative lg:col-span-6">
            <div className="grid grid-cols-6 grid-rows-6 gap-3 sm:gap-4 h-[26rem] sm:h-[34rem]">
              <Photo img={images.heroLocs} eager className="col-span-3 row-span-6 rounded-[2rem] rounded-tl-[6rem]" />
              <Photo img={images.heroNails} eager className="col-span-3 row-span-3 rounded-[2rem]" />
              <Photo img={images.heroSalon} eager className="col-span-3 row-span-3 rounded-[2rem] rounded-br-[5rem]" />
            </div>
            <div className="absolute -bottom-6 left-6 hidden items-center gap-3 rounded-2xl bg-cream-50 p-4 pr-6 text-emerald-950 shadow-2xl sm:flex">
              <span className="flex size-11 items-center justify-center rounded-xl bg-emerald-900 text-gold-300"><ListChecks className="size-5" /></span>
              <div>
                <p className="font-display text-2xl leading-none">{services.length} prestations</p>
                <p className="text-xs text-emerald-950/60">listées sur la fiche Google</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ───── MARQUEE ───── */}
      <div className="overflow-hidden border-y border-emerald-900/10 bg-cream-100 py-5" aria-hidden="true">
        <div className="flex w-max animate-marquee gap-10">
          {[...services, ...services].map((s, i) => (
            <span key={i} className="flex items-center gap-10 font-display text-2xl italic text-emerald-900/80">
              {s.name}<Sparkles className="size-4 text-gold-500" />
            </span>
          ))}
        </div>
      </div>

      {/* ───── UNIVERS (bento) ───── */}
      <section className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32">
        <div className="reveal mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <Eyebrow>Nos univers</Eyebrow>
            <SectionTitle>Cinq expertises,<br /><em className="text-gold-600">une seule adresse.</em></SectionTitle>
          </div>
          <Button asChild variant="outline"><Link to="/prestations">Toutes les prestations <ArrowRight /></Link></Button>
        </div>
        <div className="grid auto-rows-[15rem] gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:auto-rows-[17rem]">
          {categories.map((c, i) => {
            const span = ["lg:col-span-2 lg:row-span-2", "lg:row-span-2", "", "", "sm:col-span-2 lg:col-span-2"][i];
            const count = services.filter((s) => s.category === c.id).length;
            return (
              <Link
                key={c.id}
                to={`/prestations?cat=${c.id}`}
                className={`reveal group relative overflow-hidden rounded-[2rem] ${span}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <Photo img={categoryCover[c.id]} className="absolute inset-0 h-full" />
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/90 via-emerald-950/30 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-6 text-cream-50 sm:p-7">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-widest text-gold-300">{count} prestation{count > 1 ? "s" : ""}</p>
                    <h3 className="mt-1 font-display text-3xl sm:text-4xl">{c.label}</h3>
                    <p className="mt-1 text-sm text-cream-50/70">{c.tagline}</p>
                  </div>
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-cream-50 text-emerald-950 transition group-hover:rotate-45 group-hover:bg-gold-400">
                    <ArrowUpRight className="size-5" />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* ───── PROCESSUS ───── */}
      <section className="bg-cream-100 py-24 lg:py-32">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
          <div className="reveal relative order-2 lg:order-1">
            <Photo img={images.nailArt} className="aspect-[4/3] rounded-[2.5rem]" />
            <Photo img={images.lashes} className="absolute -bottom-10 -right-2 hidden aspect-square w-48 rounded-[2rem] ring-8 ring-cream-100 sm:block" />
          </div>
          <div className="reveal order-1 lg:order-2">
            <Eyebrow>Simple & rapide</Eyebrow>
            <SectionTitle>Réserver en trois étapes</SectionTitle>
            <ol className="mt-10 space-y-8">
              {[
                { I: ListChecks, t: "Choisissez votre prestation", d: "Coiffure, tresses, ongles, regard ou mariage : parcourez le catalogue complet." },
                { I: MessageSquareText, t: "Envoyez votre demande", d: "Indiquez votre date idéale via le formulaire ou WhatsApp." },
                { I: CheckCircle2, t: "Le salon vous confirme", d: "Vous recevez la confirmation de votre créneau directement." },
              ].map(({ I, t, d }, i) => (
                <li key={t} className="flex gap-5">
                  <span className="relative flex size-14 shrink-0 items-center justify-center rounded-2xl bg-emerald-900 text-gold-300">
                    <I className="size-6" />
                    <span className="absolute -right-2 -top-2 flex size-6 items-center justify-center rounded-full bg-gold-400 text-xs font-bold text-emerald-950">{i + 1}</span>
                  </span>
                  <div>
                    <h3 className="text-lg font-semibold">{t}</h3>
                    <p className="mt-1 text-emerald-950/65">{d}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-10 flex flex-wrap gap-3">
              <Button asChild size="lg"><Link to="/contact"><CalendarHeart /> Demander un rendez-vous</Link></Button>
              <WhatsAppButton size="lg" />
            </div>
          </div>
        </div>
      </section>

      {/* ───── MARIAGE ───── */}
      <section className="relative overflow-hidden bg-emerald-950 py-24 text-cream-50 lg:py-32">
        <div className="grain absolute inset-0" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-12">
          <div className="reveal lg:col-span-5">
            <Badge variant="light">Services mariée</Badge>
            <h2 className="mt-6 font-display text-5xl leading-[1] sm:text-6xl">Le grand jour <em className="text-gold-300">mérite</em> l'exception.</h2>
            <p className="mt-6 text-cream-50/70">
              Coiffure, maquillage, ongles, cils : Emerald Beauty propose des services dédiés aux mariées. Le détail des
              formules sera présenté ici après validation avec le salon.
            </p>
            <Button asChild variant="gold" size="lg" className="mt-8">
              <Link to={`/contact?service=${encodeURIComponent("Services mariée")}`}>Demander une prestation mariée <ArrowRight /></Link>
            </Button>
          </div>
          <div className="reveal grid grid-cols-2 gap-4 lg:col-span-7">
            <Photo img={images.bride} className="row-span-2 aspect-[3/4] h-full rounded-[2rem] rounded-tl-[5rem]" />
            <Photo img={images.bridalLips} className="aspect-[4/3] rounded-[2rem]" />
            <Photo img={images.bridalPrep} className="aspect-[4/3] rounded-[2rem] rounded-br-[5rem]" />
          </div>
        </div>
      </section>

      {/* ───── GALERIE APERÇU ───── */}
      <section className="py-24 lg:py-32">
        <div className="reveal mx-auto mb-12 flex max-w-7xl flex-col justify-between gap-6 px-5 sm:px-8 md:flex-row md:items-end">
          <div>
            <Eyebrow>Galerie</Eyebrow>
            <SectionTitle>Inspirations</SectionTitle>
          </div>
          <Button asChild variant="outline"><Link to="/galerie">Ouvrir la galerie <ArrowRight /></Link></Button>
        </div>
        <div className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-4 sm:px-8">
          {galleryImages.slice(0, 8).map((img, i) => (
            <Photo key={i} img={img} className={`shrink-0 snap-start rounded-[1.75rem] ${i % 2 ? "h-80 w-60" : "h-80 w-72 sm:w-80"}`} />
          ))}
        </div>
      </section>

      {/* ───── AVIS ───── */}
      <section className="bg-cream-100 py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal mb-12">
            <Eyebrow>Avis clients</Eyebrow>
            <SectionTitle>Ce que disent nos clientes</SectionTitle>
          </div>
          <ReviewsBlock />
        </div>
      </section>

      {/* ───── LOCALISATION ───── */}
      <section className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32">
        <div className="reveal"><LocationBlock /></div>
      </section>

      <CtaBand />
    </>
  );
}
