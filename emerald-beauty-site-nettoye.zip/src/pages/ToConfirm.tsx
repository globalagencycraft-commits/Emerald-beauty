import { CheckCircle2, CircleHelp, Settings2 } from "lucide-react";
import { business, services, reviews } from "@/config/business";
import { images, realPhotosToCollect } from "@/config/images";
import { useSeo } from "@/lib/router";
import { PageHero } from "@/components/shared";

const confirmed = [
  `Nom : ${business.name}`,
  `Catégorie : ${business.category}`,
  `Adresse : ${business.address.full}`,
  `Horaire visible : « Ouvert · ${business.hours.known} »`,
  `Note Google : 5,0 / 5 (${business.google.reviewCount} avis)`,
  `Avis : ${reviews.map((r) => `${r.author} (${r.service})`).join(", ")} — sans commentaire écrit`,
  `${services.length} prestations listées (onglet Services Google)`,
];

const toConfirm = [
  "Numéro de téléphone (non visible sur la fiche)",
  "Numéro WhatsApp",
  "Adresse e-mail",
  "Horaires complets jour par jour (seule la fermeture à 17 h est visible)",
  "Tarifs de chaque prestation (aucune grille tarifaire publiée)",
  "Durée des prestations et politique de réservation / acompte",
  "Comptes réseaux sociaux (Instagram, Facebook, TikTok…)",
  "Logo officiel et charte graphique (le logo actuel est une proposition)",
  "Photos originales des réalisations et du salon",
  "Texte de présentation : histoire, équipe, fondatrice",
  "Signification de « and more » : autres services éventuels",
  "Descriptions des prestations (rédigées de manière générique)",
  "Nom de domaine souhaité et hébergement",
  "Mentions légales et politique de confidentialité",
];

const config = [
  "Activer les boutons Appeler / WhatsApp / E-mail : src/config/business.ts",
  "Brancher le formulaire (Formspree, Web3Forms ou API) : champ formEndpoint",
  "Remplacer les photos de la banque d'images par celles du salon : src/config/images.ts",
  "Retirer la balise noindex et le bandeau démo dans index.html / layout au lancement",
];

export default function ToConfirm() {
  useSeo("Informations à confirmer — Démo Emerald Beauty and more", "Liste des informations à valider avec le salon avant mise en ligne.");
  const Block = ({ title, items, icon: I, tone }: { title: string; items: string[]; icon: typeof CheckCircle2; tone: string }) => (
    <div className="rounded-[2rem] bg-white p-8 ring-1 ring-emerald-900/8">
      <h2 className="font-display text-3xl">{title}</h2>
      <ul className="mt-6 space-y-3">
        {items.map((t) => (
          <li key={t} className="flex gap-3 text-sm text-emerald-950/80">
            <I className={`mt-0.5 size-4 shrink-0 ${tone}`} /> {t}
          </li>
        ))}
      </ul>
    </div>
  );
  return (
    <>
      <PageHero
        eyebrow="Document de travail"
        title={<>Informations <em className="text-gold-300">à confirmer</em></>}
        intro="Ce site est une démonstration préparée à partir de la fiche Google publique. Voici ce qui est vérifié et ce qui reste à valider avec la propriétaire."
        img={images.stylist}
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-20 sm:px-8 lg:grid-cols-2">
        <Block title="Vérifié (fiche Google)" items={confirmed} icon={CheckCircle2} tone="text-emerald-600" />
        <Block title="À confirmer" items={toConfirm} icon={CircleHelp} tone="text-gold-600" />
        <Block title="Photos Google à récupérer" items={realPhotosToCollect} icon={CircleHelp} tone="text-gold-600" />
        <Block title="Configuration technique" items={config} icon={Settings2} tone="text-emerald-800" />
      </section>
    </>
  );
}
