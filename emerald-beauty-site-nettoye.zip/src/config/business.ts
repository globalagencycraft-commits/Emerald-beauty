/**
 * ─────────────────────────────────────────────────────────────
 *  CONFIGURATION CENTRALE — Emerald Beauty and more (DÉMO)
 * ─────────────────────────────────────────────────────────────
 *  Toutes les informations ci-dessous proviennent UNIQUEMENT de la
 *  fiche Google Business Profile publique (captures du 13 nov.).
 *  Les champs à `null` sont INCONNUS et doivent être confirmés par
 *  la propriétaire avant toute mise en ligne.
 */

export const business = {
  name: "Emerald Beauty and more",
  shortName: "Emerald Beauty",
  category: "Salon de beauté",
  address: {
    street: "7 Rue Crepsac",
    area: "Delmas 40B",
    city: "Port-au-Prince",
    country: "Haïti",
    full: "7 Rue Crepsac, Delmas 40B, Port-au-Prince",
  },
  google: {
    rating: 5.0,
    reviewCount: 2,
    mapsUrl:
      "https://www.google.com/maps/search/?api=1&query=" +
      encodeURIComponent("Emerald Beauty and more, 7 Rue Crepsac, Delmas 40B, Port-au-Prince"),
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=" +
      encodeURIComponent("Emerald Beauty and more, 7 Rue Crepsac, Delmas 40B, Port-au-Prince"),
    embedUrl:
      "https://www.google.com/maps?q=" +
      encodeURIComponent("Emerald Beauty and more, Delmas 40B, Port-au-Prince") +
      "&output=embed",
  },
  /** Seule information visible : « Ouvert · Ferme à 17 h ». */
  hours: {
    known: "Ferme à 17 h",
    detailed: null as null | { day: string; hours: string }[],
  },

  // ───── À CONFIGURER (inconnu à ce jour) ─────
  /** Format international sans espaces, ex. "+50930000000" */
  phone: null as string | null,
  /** Numéro WhatsApp, format international sans « + », ex. "50930000000" */
  whatsapp: null as string | null,
  email: null as string | null,
  social: {
    instagram: null as string | null,
    facebook: null as string | null,
    tiktok: null as string | null,
  },
  /** Endpoint de formulaire (Formspree, Web3Forms, API maison…) */
  formEndpoint: null as string | null,
} as const;

export type ServiceCategoryId = "coiffure" | "tresses" | "ongles" | "regard" | "mariage";

export interface Service {
  /** Libellé exact sur Google (anglais) */
  google: string;
  /** Libellé français affiché */
  name: string;
  description: string;
  category: ServiceCategoryId;
}

/** Les 16 prestations listées sur la fiche Google — aucune ajoutée. */
export const services: Service[] = [
  { google: "Balayage", name: "Balayage", category: "coiffure", description: "Technique de coloration pour des reflets lumineux et naturels." },
  { google: "Blow dry", name: "Brushing", category: "coiffure", description: "Séchage et mise en forme au sèche-cheveux pour un fini lisse et volumineux." },
  { google: "Hairstyling", name: "Coiffage", category: "coiffure", description: "Coiffures pour le quotidien ou pour vos événements." },
  { google: "Perms", name: "Permanente", category: "coiffure", description: "Transformation durable de la texture du cheveu." },
  { google: "Shampoo & conditioning", name: "Shampoing & soin", category: "coiffure", description: "Lavage et soin démêlant pour des cheveux propres et nourris." },
  { google: "Hair extensions", name: "Extensions de cheveux", category: "coiffure", description: "Pose d'extensions pour gagner en longueur et en volume." },
  { google: "Box braids", name: "Box braids", category: "tresses", description: "Tresses individuelles à séparations carrées, protectrices et polyvalentes." },
  { google: "Braids", name: "Tresses", category: "tresses", description: "Tresses et nattes de styles variés." },
  { google: "Dreadlocks", name: "Dreadlocks / Locs", category: "tresses", description: "Création et entretien de locs." },
  { google: "Manicure", name: "Manucure", category: "ongles", description: "Soin des mains et mise en beauté des ongles." },
  { google: "Acrylic nails", name: "Ongles en acrylique", category: "ongles", description: "Pose d'ongles en résine acrylique, formes et décors au choix." },
  { google: "Pedicure", name: "Pédicure", category: "ongles", description: "Soin des pieds et mise en beauté des ongles." },
  { google: "Eyebrow beautification", name: "Beauté des sourcils", category: "regard", description: "Mise en forme des sourcils pour structurer le regard." },
  { google: "Eyelash extensions", name: "Extensions de cils", category: "regard", description: "Pose de cils pour un regard intensifié." },
  { google: "Make-up services", name: "Maquillage", category: "regard", description: "Mise en beauté du teint et du regard." },
  { google: "Bridal services", name: "Services mariée", category: "mariage", description: "Mise en beauté pour le jour J." },
];

export const categories: { id: ServiceCategoryId; label: string; tagline: string }[] = [
  { id: "coiffure", label: "Coiffure", tagline: "Couleur, brushing & coiffage" },
  { id: "tresses", label: "Tresses & Locs", tagline: "Box braids, tresses, dreadlocks" },
  { id: "ongles", label: "Ongles", tagline: "Manucure, acrylique, pédicure" },
  { id: "regard", label: "Regard & Maquillage", tagline: "Sourcils, cils, make-up" },
  { id: "mariage", label: "Mariage", tagline: "Services mariée" },
];

/** Avis Google réels (aucun commentaire écrit n'est visible sur la fiche). */
export const reviews = [
  { author: "Shelove Zaporte", initial: "S", color: "bg-teal-600", rating: 5, when: "il y a environ un an", service: "Tresses (Braids)" },
  { author: "Vitalherne Labossiere", initial: "V", color: "bg-pink-600", rating: 5, when: "il y a environ un an", service: "Manucure" },
];

export const whatsappLink = (message: string) =>
  business.whatsapp ? `https://wa.me/${business.whatsapp}?text=${encodeURIComponent(message)}` : null;
