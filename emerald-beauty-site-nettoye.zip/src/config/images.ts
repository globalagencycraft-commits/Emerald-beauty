/**
 * Photos de banque d'images libres de droits (Pexels).
 * ⚠️ Ce ne sont PAS des réalisations du salon : à remplacer par les
 * vraies photos d'Emerald Beauty and more avant la mise en ligne.
 */
import type { ServiceCategoryId } from "./business";

const px = (id: number, w = 1000, h?: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w}${h ? `&h=${h}&fit=crop` : ""}`;

export interface Img {
  src: string;
  alt: string;
  credit: string;
  category: ServiceCategoryId | "salon";
  tall?: boolean;
}

export const images = {
  heroLocs: { src: px(37010087, 900, 1200), alt: "Femme aux cheveux naturels coiffés, maquillage doux", credit: "Tress Alchemy Inc. / Pexels", category: "coiffure", tall: true },
  heroNails: { src: px(34885844, 800, 800), alt: "Main avec nail art rose et bague dorée", credit: "Salim Da / Pexels", category: "ongles" },
  heroSalon: { src: px(6135674, 900, 700), alt: "Espace pédicure avec fauteuils confortables", credit: "Gabriel Puyén / Pexels", category: "salon" },
  braids: { src: px(28383173, 900, 1100), alt: "Réalisation de tresses en gros plan", credit: "Adenir Figueiredo Carvalho / Pexels", category: "tresses", tall: true },
  braidsColor: { src: px(35382770, 900, 1100), alt: "Tresses colorées aux reflets rose et orange", credit: "Diana / Pexels", category: "tresses", tall: true },
  braidsPattern: { src: px(4671331, 900, 900), alt: "Motif de tresses vu de dessus", credit: "Gift Habeshaw / Pexels", category: "tresses" },
  locs: { src: px(12530818, 800, 1100), alt: "Femme souriante portant des locs", credit: "davidowaga / Pexels", category: "tresses", tall: true },
  french: { src: px(35031987, 900, 1100), alt: "Manucure french élégante", credit: "Salim Da / Pexels", category: "ongles", tall: true },
  nailArt: { src: px(5484948, 900, 700), alt: "Séance de manucure avec nail art détaillé", credit: "Felix Adams / Pexels", category: "ongles" },
  nailsRed: { src: px(34885845, 800, 800), alt: "Ongles rouges décorés et bague dorée", credit: "Salim Da / Pexels", category: "ongles" },
  pedicure: { src: px(6135677, 900, 700), alt: "Fauteuils et bains de pieds pour pédicure", credit: "Gabriel Puyén / Pexels", category: "salon" },
  pedicureChair: { src: px(7195798, 800, 1000), alt: "Fauteuil de pédicure dans un salon moderne", credit: "Max Vakhtbovych / Pexels", category: "salon", tall: true },
  blowdry: { src: px(30270930, 800, 1000), alt: "Femme aux cheveux longs avec sèche-cheveux", credit: "Chad Populis / Pexels", category: "coiffure", tall: true },
  stylist: { src: px(7388971, 900, 700), alt: "Coiffeuse réalisant un brushing", credit: "John Diez / Pexels", category: "coiffure" },
  tools: { src: px(30270920, 800, 1000), alt: "Femme tenant des outils de coiffure", credit: "Chad Populis / Pexels", category: "coiffure", tall: true },
  lashes: { src: px(8554941, 900, 700), alt: "Pose d'extensions de cils", credit: "Екатерина Мясоед / Pexels", category: "regard" },
  brows: { src: px(31261686, 900, 700), alt: "Soin professionnel des sourcils", credit: "José Antonio Otegui Auzmendi / Pexels", category: "regard" },
  makeup: { src: px(10157842, 800, 1100), alt: "Femme se maquillant au pinceau", credit: "Roman Odintsov / Pexels", category: "regard", tall: true },
  bridalLips: { src: px(33927084, 1000, 700), alt: "Maquillage d'une mariée, gros plan sur les lèvres", credit: "Chidi Young / Pexels", category: "mariage" },
  bride: { src: px(37469508, 900, 1200), alt: "Mariée tenant un bouquet de roses rouges", credit: "Dionisio Tivane / Pexels", category: "mariage", tall: true },
  bridalPrep: { src: px(37008184, 900, 1100), alt: "Préparation coiffure d'une mariée", credit: "Alfredo Dacosta / Pexels", category: "mariage", tall: true },
} satisfies Record<string, Img>;

export const categoryCover: Record<ServiceCategoryId, Img> = {
  coiffure: images.blowdry,
  tresses: images.braids,
  ongles: images.french,
  regard: images.lashes,
  mariage: images.bride,
};

export const galleryImages: Img[] = [
  images.braids, images.nailArt, images.locs, images.pedicure, images.french,
  images.lashes, images.blowdry, images.bridalLips, images.braidsColor, images.nailsRed,
  images.makeup, images.pedicureChair, images.brows, images.bride, images.braidsPattern,
  images.stylist, images.tools, images.bridalPrep, images.heroNails, images.heroSalon,
];

/** Photos réellement présentes sur la fiche Google (à récupérer auprès du salon). */
export const realPhotosToCollect = [
  "Intérieur du salon : fauteuils de pédicure bleu nuit, tabourets dorés, décor de ballons verts et jaunes",
  "Ongles amande roses avec french blanche en vague",
  "Ongles blancs avec décor doré et paillettes argentées",
  "Locs rouges devant l'enseigne lumineuse « Emerald Beauty » et herbes de pampa",
];
