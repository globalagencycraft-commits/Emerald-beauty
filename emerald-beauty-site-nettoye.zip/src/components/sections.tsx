import { Clock, MapPin, Navigation, ExternalLink, Quote, CalendarHeart } from "lucide-react";
import { business, reviews } from "@/config/business";
import { images } from "@/config/images";
import { Link } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { Badge, Stars } from "@/components/ui/misc";
import { CallButton, Eyebrow, SectionTitle, WhatsAppButton } from "@/components/shared";

export function GoogleG({ className = "size-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.4-.4-3.5z" />
      <path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
    </svg>
  );
}

export function ReviewsBlock({ full = false }: { full?: boolean }) {
  return (
    <div className="grid gap-6 lg:grid-cols-12">
      <div className="reveal relative overflow-hidden rounded-[2rem] bg-emerald-950 p-8 text-cream-50 lg:col-span-5 sm:p-10">
        <div className="grain absolute inset-0" />
        <div className="relative">
          <div className="flex items-center gap-2 text-sm text-cream-50/70"><GoogleG /> Note Google</div>
          <p className="mt-6 font-display text-8xl leading-none">5,0</p>
          <Stars className="mt-3 [&_svg]:size-6" />
          <p className="mt-3 text-sm text-cream-50/65">Sur la base de {business.google.reviewCount} avis Google publics.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="gold" size="sm">
              <a href={business.google.mapsUrl} target="_blank" rel="noopener noreferrer">Voir sur Google <ExternalLink /></a>
            </Button>
            <Button asChild variant="outlineLight" size="sm">
              <a href={business.google.mapsUrl} target="_blank" rel="noopener noreferrer">Laisser un avis</a>
            </Button>
          </div>
        </div>
      </div>
      <div className="grid gap-6 lg:col-span-7">
        {reviews.map((r, i) => (
          <article key={r.author} className="reveal flex flex-col justify-between rounded-[2rem] bg-white p-7 ring-1 ring-emerald-900/8 sm:p-8" style={{ transitionDelay: `${i * 120}ms` }}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <span className={`flex size-12 items-center justify-center rounded-full text-lg font-semibold text-white ${r.color}`} aria-hidden="true">{r.initial}</span>
                <div>
                  <h3 className="font-semibold text-emerald-950">{r.author}</h3>
                  <p className="text-xs text-emerald-950/55">{r.when} · via Google</p>
                </div>
              </div>
              <Quote className="size-8 shrink-0 text-gold-400/50" aria-hidden="true" />
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Stars />
              <Badge variant="gold">Prestation : {r.service}</Badge>
            </div>
            {full && <p className="mt-4 text-xs italic text-emerald-950/50">Note 5 étoiles sans commentaire écrit.</p>}
          </article>
        ))}
      </div>
    </div>
  );
}

export function LocationBlock() {
  return (
    <div className="grid overflow-hidden rounded-[2rem] bg-white ring-1 ring-emerald-900/8 lg:grid-cols-5">
      <div className="p-8 sm:p-10 lg:col-span-2">
        <Eyebrow>Le salon</Eyebrow>
        <SectionTitle className="!text-4xl">Venez nous rendre visite</SectionTitle>
        <ul className="mt-8 space-y-6">
          <li className="flex gap-4">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-900 text-gold-300"><MapPin className="size-5" /></span>
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-950/50">Adresse</p>
              <address className="mt-1 not-italic text-emerald-950">{business.address.street}<br />{business.address.area}, {business.address.city}</address>
            </div>
          </li>
          <li className="flex gap-4">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-900 text-gold-300"><Clock className="size-5" /></span>
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-950/50">Horaires</p>
              <p className="mt-1 text-emerald-950">{business.hours.known}</p>
              <p className="mt-1 text-xs text-emerald-950/55">Jours et heures d'ouverture détaillés à confirmer.</p>
            </div>
          </li>
        </ul>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button asChild>
            <a href={business.google.directionsUrl} target="_blank" rel="noopener noreferrer"><Navigation /> Itinéraire</a>
          </Button>
          <CallButton variant="outline" />
          <WhatsAppButton />
        </div>
      </div>
      <div className="relative min-h-80 lg:col-span-3">
        <iframe
          title={`Carte — ${business.name}, ${business.address.full}`}
          src={business.google.embedUrl}
          className="absolute inset-0 h-full w-full border-0 grayscale-[30%]"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          sandbox="allow-scripts allow-same-origin allow-popups"
        />
      </div>
    </div>
  );
}

export function CtaBand() {
  return (
    <section className="px-5 pb-24 sm:px-8">
      <div className="reveal relative mx-auto max-w-7xl overflow-hidden rounded-[2.5rem] bg-emerald-900 text-cream-50">
        <img src={images.braidsColor.src} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-950 via-emerald-950/85 to-emerald-900/40" />
        <div className="relative flex flex-col items-start gap-8 p-10 sm:p-16 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl">
            <Eyebrow light>Rendez-vous</Eyebrow>
            <SectionTitle light>Prête pour votre prochaine mise en beauté ?</SectionTitle>
            <p className="mt-4 text-cream-50/70">Envoyez votre demande en moins d'une minute, le salon vous confirme le créneau.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="gold" size="lg"><Link to="/contact"><CalendarHeart /> Demander un rendez-vous</Link></Button>
            <WhatsAppButton size="lg" />
          </div>
        </div>
      </div>
    </section>
  );
}
