import { useMemo, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { CalendarHeart, Check, Copy, Send, ShieldCheck } from "lucide-react";
import { business, categories, services, whatsappLink } from "@/config/business";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/misc";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";

type Errors = Partial<Record<"name" | "contact" | "service" | "date" | "consent", string>>;

const clean = (s: string, max = 500) => s.replace(/[<>]/g, "").trim().slice(0, max);

export function BookingForm({ defaultService = "" }: { defaultService?: string }) {
  const [errors, setErrors] = useState<Errors>({});
  const [preview, setPreview] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const today = useMemo(() => new Date().toISOString().split("T")[0], []);
  const validDefault = services.some((s) => s.name === defaultService) ? defaultService : "";

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (fd.get("website")) return; // honeypot anti-spam

    const data = {
      name: clean(String(fd.get("name") ?? ""), 80),
      contact: clean(String(fd.get("contact") ?? ""), 40),
      service: clean(String(fd.get("service") ?? ""), 80),
      date: String(fd.get("date") ?? ""),
      moment: clean(String(fd.get("moment") ?? ""), 20),
      message: clean(String(fd.get("message") ?? ""), 600),
      consent: fd.get("consent") === "on",
    };

    const errs: Errors = {};
    if (data.name.length < 2) errs.name = "Indiquez votre nom.";
    if (!/^[+\d][\d\s().-]{6,}$/.test(data.contact)) errs.contact = "Numéro de téléphone / WhatsApp invalide.";
    if (!data.service) errs.service = "Choisissez une prestation.";
    if (data.date && data.date < today) errs.date = "La date doit être dans le futur.";
    if (!data.consent) errs.consent = "Merci d'accepter d'être recontacté(e).";
    setErrors(errs);
    if (Object.keys(errs).length) {
      toast.error("Veuillez corriger les champs indiqués.");
      return;
    }

    const dateFr = data.date
      ? new Date(data.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })
      : "à convenir";
    const text = [
      `Bonjour ${business.name} 👋`,
      `Je souhaite prendre rendez-vous.`,
      ``,
      `• Nom : ${data.name}`,
      `• Téléphone : ${data.contact}`,
      `• Prestation : ${data.service}`,
      `• Date souhaitée : ${dateFr}${data.moment ? ` (${data.moment})` : ""}`,
      data.message ? `• Message : ${data.message}` : "",
    ].filter(Boolean).join("\n");

    if (business.formEndpoint) {
      try {
        setSending(true);
        const res = await fetch(business.formEndpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ ...data, text }),
        });
        if (!res.ok) throw new Error();
        toast.success("Demande envoyée ! Le salon vous recontactera.");
        e.currentTarget.reset();
      } catch {
        toast.error("Envoi impossible. Réessayez ou contactez le salon.");
      } finally {
        setSending(false);
      }
      return;
    }
    const wa = whatsappLink(text);
    if (wa) {
      window.open(wa, "_blank", "noopener,noreferrer");
      return;
    }
    setPreview(text);
  }

  const err = (k: keyof Errors) =>
    errors[k] ? <p id={`${k}-err`} className="mt-1.5 text-xs font-medium text-red-600">{errors[k]}</p> : null;

  return (
    <>
      <form onSubmit={onSubmit} noValidate className="space-y-5" aria-label="Demande de rendez-vous">
        <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <Label htmlFor="name">Nom complet *</Label>
            <Input id="name" name="name" autoComplete="name" placeholder="Votre nom" maxLength={80} aria-invalid={!!errors.name} aria-describedby="name-err" />
            {err("name")}
          </div>
          <div>
            <Label htmlFor="contact">Téléphone / WhatsApp *</Label>
            <Input id="contact" name="contact" type="tel" inputMode="tel" autoComplete="tel" placeholder="+509 …" maxLength={40} aria-invalid={!!errors.contact} aria-describedby="contact-err" />
            {err("contact")}
          </div>
        </div>
        <div>
          <Label htmlFor="service">Prestation souhaitée *</Label>
          <Select id="service" name="service" defaultValue={validDefault} key={validDefault} aria-invalid={!!errors.service} aria-describedby="service-err">
            <option value="" disabled>Choisir une prestation…</option>
            {categories.map((c) => (
              <optgroup key={c.id} label={c.label}>
                {services.filter((s) => s.category === c.id).map((s) => (
                  <option key={s.name} value={s.name}>{s.name}</option>
                ))}
              </optgroup>
            ))}
          </Select>
          {err("service")}
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <Label htmlFor="date">Date souhaitée</Label>
            <Input id="date" name="date" type="date" min={today} aria-invalid={!!errors.date} aria-describedby="date-err" />
            {err("date")}
          </div>
          <div>
            <Label htmlFor="moment">Moment préféré</Label>
            <Select id="moment" name="moment" defaultValue="">
              <option value="">Indifférent</option>
              <option value="matin">Matin</option>
              <option value="après-midi">Après-midi</option>
            </Select>
          </div>
        </div>
        <div>
          <Label htmlFor="message">Précisions (longueur, style, inspiration…)</Label>
          <Textarea id="message" name="message" maxLength={600} placeholder="Décrivez ce que vous souhaitez." />
        </div>
        <div>
          <label className="flex items-start gap-3 text-sm text-emerald-950/75">
            <input type="checkbox" name="consent" className="mt-0.5 size-4 accent-emerald-800" aria-describedby="consent-err" />
            J'accepte d'être recontacté(e) par le salon au sujet de ma demande. Mes informations ne sont utilisées qu'à cette fin.
          </label>
          {err("consent")}
        </div>
        <Button type="submit" size="lg" className="w-full" disabled={sending}>
          {sending ? "Envoi…" : (<><Send /> Envoyer ma demande</>)}
        </Button>
        <p className="flex items-center justify-center gap-1.5 text-center text-xs text-emerald-950/55">
          <ShieldCheck className="size-3.5" /> Demande sans engagement — le salon confirme le créneau.
        </p>
      </form>

      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent>
          <div className="mb-4 inline-flex size-12 items-center justify-center rounded-2xl bg-emerald-900 text-gold-300">
            <CalendarHeart className="size-6" />
          </div>
          <DialogTitle>Demande prête ✨</DialogTitle>
          <DialogDescription>
            Mode démonstration : en production, ce message serait envoyé directement au salon par WhatsApp ou e-mail
            (à configurer). Voici l'aperçu reçu par le salon :
          </DialogDescription>
          <pre className="mt-4 max-h-60 overflow-auto whitespace-pre-wrap rounded-2xl bg-white p-4 font-sans text-sm text-emerald-950 ring-1 ring-emerald-900/10">
            {preview}
          </pre>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <Button
              variant="outline"
              onClick={() => {
                navigator.clipboard?.writeText(preview ?? "").then(
                  () => toast.success("Message copié"),
                  () => toast.error("Copie impossible")
                );
              }}
            >
              <Copy /> Copier
            </Button>
            <Button onClick={() => setPreview(null)}><Check /> Terminer</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
