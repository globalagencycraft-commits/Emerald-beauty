import * as React from "react";
import * as TabsPrimitive from "@radix-ui/react-tabs";
import { cn } from "@/utils/cn";

export const Tabs = TabsPrimitive.Root;

export function TabsList({ className, ...props }: React.ComponentProps<typeof TabsPrimitive.List>) {
  return (
    <TabsPrimitive.List
      className={cn("no-scrollbar flex gap-2 overflow-x-auto rounded-full bg-emerald-900/5 p-1.5", className)}
      {...props}
    />
  );
}

export function TabsTrigger({ className, ...props }: React.ComponentProps<typeof TabsPrimitive.Trigger>) {
  return (
    <TabsPrimitive.Trigger
      className={cn(
        "shrink-0 rounded-full px-4 py-2 text-sm font-medium text-emerald-950/70 transition hover:text-emerald-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400 data-[state=active]:bg-emerald-900 data-[state=active]:text-cream-50 data-[state=active]:shadow cursor-pointer",
        className
      )}
      {...props}
    />
  );
}

export function TabsContent({ className, ...props }: React.ComponentProps<typeof TabsPrimitive.Content>) {
  return <TabsPrimitive.Content className={cn("mt-8 focus-visible:outline-none data-[state=active]:animate-fade-up", className)} {...props} />;
}
