import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/utils/cn";

export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0 cursor-pointer",
  {
    variants: {
      variant: {
        default: "bg-emerald-900 text-cream-50 hover:bg-emerald-800 shadow-lg shadow-emerald-950/20",
        gold: "bg-gold-400 text-emerald-950 hover:bg-gold-300 shadow-lg shadow-gold-500/25",
        outline: "border border-emerald-900/20 bg-transparent text-emerald-950 hover:bg-emerald-900/5",
        outlineLight: "border border-cream-50/30 bg-transparent text-cream-50 hover:bg-cream-50/10",
        ghost: "text-emerald-950 hover:bg-emerald-900/5",
        whatsapp: "bg-[#25D366] text-white hover:bg-[#1ebe5b] shadow-lg shadow-green-600/20",
        link: "text-emerald-800 underline-offset-4 hover:underline px-0",
      },
      size: {
        default: "h-11 px-6",
        sm: "h-9 px-4 text-xs",
        lg: "h-13 px-8 text-base",
        icon: "size-10",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  }
);
Button.displayName = "Button";
