import { createContext, useContext, useState, type ReactNode } from "react";
import { Phone, MessageCircle, Settings2 } from "lucide-react";
import { business, whatsappLink } from "@/config/business";
import type { Img } from "@/config/images";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/utils/cn";

/* ───────── Dialogue « fonctionnalité à configurer » ───────── */
type Feature = { title: string; detail: string } | null;
const ConfigCtx = createContext<(f: Feature) => void>(() => {});
export const useNotConfigured = () => useContext(ConfigCtx);

export function ConfigProvider({ children }: { children: ReactNode }) {
  const [feature, setFeature] = useState<Feature>(null);
  return (
    <ConfigCtx.Provider value={setFeature}>
      {children}
      <Dialog open={!!feature} onOpenChange={(o) => !o && setFeature(null)}>
        <DialogContent>
          <div className="mb-4 inline-flex size-12 items-center justify-center rounded-2xl bg-gold-400/15 text-gold-700">
            <Settings2 className="size-6" />
          </div>
          <DialogTitle>{feature?.title}</DialogTitle>
          <DialogDescription>{feature?.detail}</DialogDescription>
          <p className="mt-4 rounded-xl bg-emerald-900/5 p-3 text-xs text-emerald-950/70">
            Version de démonstration : ce bouton est déjà intégré. Il deviendra actif dès que l'information sera
            confirmée par le salon (fichier <code className="font-mono">src/config/business.ts</code>).
          </p>
          <Button className="mt-6 w-full" onClick={() => setFeature(null)}>
            J'ai compris
          </Button>
        </DialogContent>
      </Dialog>
    </ConfigCtx.Provider>
  );
}

export function CallButton({ children, ...props }: ButtonProps) {
  const notConfigured = useNotConfigured();
  const label = children ?? (<><Phone /> Appeler</>);
  if (business.phone)
    return (
      <Button asChild {...props}>
        <a href={`tel:${business.phone}`}>{label}</a>
      </Button>
    );
  return (
    <Button
      {...props}
      onClick={() =>
        notConfigured({
          title: "Appel téléphonique — à configurer",
          detail: "Aucun numéro de téléphone n'apparaît sur la fiche Google. Le bouton « Appeler » lancera l'appel directement depuis le mobile du visiteur.",
        })
      }
    >
      {label}
    </Button>
  );
}

export function WhatsAppButton({ message, children, ...props }: ButtonProps & { message?: string }) {
  const notConfigured = useNotConfigured();
  const msg = message ?? `Bonjour ${business.name}, je souhaite prendre rendez-vous.`;
  const href = whatsappLink(msg);
  const label = children ?? (<><MessageCircle /> WhatsApp</>);
  if (href)
    return (
      <Button asChild variant="whatsapp" {...props}>
        <a href={href} target="_blank" rel="noopener noreferrer">{label}</a>
      </Button>
    );
  return (
    <Button
      variant="whatsapp"
      {...props}
      onClick={() =>
        notConfigured({
          title: "WhatsApp — à configurer",
          detail: "Le numéro WhatsApp du salon n'est pas encore connu. Une fois ajouté, ce bouton ouvrira une conversation avec un message pré-rempli.",
        })
      }
    >
      {label}
    </Button>
  );
}

/* ───────── Logo ───────── */
export function Logo({ light = false, className }: { light?: boolean; className?: string }) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <svg viewBox="0 0 40 40" className="size-9 shrink-0" aria-hidden="true">
        <path d="M20 2 34 12v16L20 38 6 28V12Z" className={light ? "fill-gold-400" : "fill-emerald-900"} />
        <path d="M20 8 29 14.5v11L20 32l-9-6.5v-11Z" className={light ? "fill-emerald-950" : "fill-gold-400"} />
        <path d="M20 8v24M11 14.5l18 11M29 14.5l-18 11" className={light ? "stroke-gold-400/50" : "stroke-emerald-900/30"} strokeWidth=".8" />
      </svg>
      <span className="leading-none">
        <span className={cn("block font-display text-xl font-semibold tracking-wide", light ? "text-cream-50" : "text-emerald-950")}>
          Emerald Beauty
        </span>
        <span className={cn("block text-[10px] font-semibold uppercase tracking-[0.3em]", light ? "text-gold-300" : "text-gold-600")}>
          and more
        </span>
      </span>
    </span>
  );
}

/* ───────── Photo ───────── */
export function Photo({
  img,
  className,
  imgClassName,
  eager,
}: {
  img: Img;
  className?: string;
  imgClassName?: string;
  eager?: boolean;
}) {
  return (
    <figure className={cn("group relative overflow-hidden bg-emerald-900/10", className)}>
      <img
        src={img.src}
        alt={img.alt}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        className={cn("h-full w-full object-cover transition-transform duration-700 group-hover:scale-105", imgClassName)}
      />
    </figure>
  );
}

/* ───────── Titres de section ───────── */
export function Eyebrow({ children, light }: { children: ReactNode; light?: boolean }) {
  return (
    <p className={cn("mb-4 flex items-center gap-3 text-xs font-bold uppercase tracking-[0.25em]", light ? "text-gold-300" : "text-gold-600")}>
      <span className={cn("h-px w-8", light ? "bg-gold-300" : "bg-gold-500")} />
      {children}
    </p>
  );
}

export function SectionTitle({ children, light, className }: { children: ReactNode; light?: boolean; className?: string }) {
  return (
    <h2 className={cn("text-balance font-display text-4xl font-medium leading-[1.05] sm:text-5xl", light ? "text-cream-50" : "text-emerald-950", className)}>
      {children}
    </h2>
  );
}

export function PageHero({ eyebrow, title, intro, img }: { eyebrow: string; title: ReactNode; intro: string; img?: Img }) {
  return (
    <section className="relative overflow-hidden bg-emerald-950 text-cream-50">
      <div className="grain absolute inset-0" />
      {img && (
        <div className="absolute inset-0 lg:left-auto lg:w-1/2">
          <img src={img.src} alt="" className="h-full w-full object-cover opacity-30 lg:opacity-40" />
          <div className="absolute inset-0 bg-emerald-950/55 lg:hidden" />
          <div className="absolute inset-0 hidden bg-gradient-to-r from-emerald-950 via-emerald-950/60 to-transparent lg:block" />
        </div>
      )}
      <div className="relative mx-auto max-w-7xl px-5 pb-16 pt-32 sm:px-8 sm:pb-20 sm:pt-40">
        <Eyebrow light>{eyebrow}</Eyebrow>
        <h1 className="max-w-3xl text-balance font-display text-5xl font-medium leading-[1] sm:text-6xl lg:text-7xl">{title}</h1>
        <p className="mt-6 max-w-xl text-base text-cream-100/75 sm:text-lg">{intro}</p>
      </div>
    </section>
  );
}
