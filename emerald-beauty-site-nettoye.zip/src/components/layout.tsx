import { useEffect, useState } from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { Menu, X, MapPin, Clock, CalendarHeart, Navigation, Info, Phone, MessageCircle } from "lucide-react";

const Instagram = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" fill="currentColor" />
  </svg>
);
const Facebook = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
    <path d="M14 8h3V4h-3a4 4 0 0 0-4 4v2H7v4h3v8h4v-8h3l1-4h-4V8z" />
  </svg>
);
import { business } from "@/config/business";
import { Link } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { CallButton, Logo, WhatsAppButton, useNotConfigured } from "@/components/shared";
import { cn } from "@/utils/cn";

export const NAV = [
  { to: "/", label: "Accueil" },
  { to: "/prestations", label: "Prestations" },
  { to: "/galerie", label: "Galerie" },
  { to: "/avis", label: "Avis" },
  { to: "/contact", label: "Contact" },
];

export function DemoBanner() {
  return (
    <div className="relative z-[60] bg-gold-400 px-4 py-2 text-center text-[11px] font-semibold text-emerald-950 sm:text-xs">
      <Info className="mr-1.5 inline size-3.5 -translate-y-px" aria-hidden="true" />
      Site de démonstration — proposition non officielle, non encore approuvée par {business.name}.{" "}
      <Link to="/a-confirmer" className="underline underline-offset-2 hover:no-underline">
        Informations à confirmer
      </Link>
    </div>
  );
}

export function Header({ path }: { path: string }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => setOpen(false), [path]);

  const solid = scrolled;
  return (
    <header
      className={cn(
        "fixed inset-x-0 z-50 transition-all duration-300",
        solid ? "top-0 bg-cream-50/90 shadow-sm backdrop-blur-xl" : "top-[34px] bg-transparent sm:top-[32px]"
      )}
    >
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
        <Link to="/" aria-label={`${business.name} — accueil`}>
          <Logo light={!solid} />
        </Link>

        <nav aria-label="Navigation principale" className="hidden lg:block">
          <ul className={cn("flex items-center gap-1 rounded-full p-1", solid ? "" : "bg-white/5 ring-1 ring-white/10 backdrop-blur")}>
            {NAV.map((n) => {
              const active = path === n.to;
              return (
                <li key={n.to}>
                  <Link
                    to={n.to}
                    aria-current={active ? "page" : undefined}
                    className={cn(
                      "rounded-full px-4 py-2 text-sm font-medium transition",
                      solid
                        ? active ? "bg-emerald-900 text-cream-50" : "text-emerald-950/75 hover:text-emerald-950"
                        : active ? "bg-cream-50 text-emerald-950" : "text-cream-50/80 hover:text-cream-50"
                    )}
                  >
                    {n.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild variant={solid ? "default" : "gold"} size="sm" className="hidden sm:inline-flex">
            <Link to="/contact"><CalendarHeart /> Prendre rendez-vous</Link>
          </Button>
          <DialogPrimitive.Root open={open} onOpenChange={setOpen}>
            <DialogPrimitive.Trigger asChild>
              <Button variant={solid ? "outline" : "outlineLight"} size="icon" className="lg:hidden" aria-label="Ouvrir le menu">
                <Menu />
              </Button>
            </DialogPrimitive.Trigger>
            <DialogPrimitive.Portal>
              <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-emerald-950/60 backdrop-blur-sm data-[state=open]:animate-fade-in" />
              <DialogPrimitive.Content className="fixed inset-y-0 right-0 z-50 flex w-[86%] max-w-sm flex-col bg-emerald-950 p-6 text-cream-50 shadow-2xl data-[state=open]:animate-fade-in">
                <div className="flex items-center justify-between">
                  <Logo light />
                  <DialogPrimitive.Close className="rounded-full p-2 hover:bg-white/10" aria-label="Fermer le menu">
                    <X className="size-6" />
                  </DialogPrimitive.Close>
                </div>
                <DialogPrimitive.Title className="sr-only">Menu</DialogPrimitive.Title>
                <DialogPrimitive.Description className="sr-only">Navigation du site</DialogPrimitive.Description>
                <nav className="mt-10 flex flex-col">
                  {NAV.map((n, i) => (
                    <Link
                      key={n.to}
                      to={n.to}
                      className={cn(
                        "flex items-baseline gap-4 border-b border-white/10 py-4 font-display text-3xl transition hover:text-gold-300",
                        path === n.to && "text-gold-300"
                      )}
                    >
                      <span className="font-sans text-xs text-cream-50/40">0{i + 1}</span>
                      {n.label}
                    </Link>
                  ))}
                </nav>
                <div className="mt-auto space-y-3">
                  <Button asChild variant="gold" className="w-full">
                    <Link to="/contact"><CalendarHeart /> Prendre rendez-vous</Link>
                  </Button>
                  <div className="grid grid-cols-2 gap-3">
                    <CallButton variant="outlineLight" />
                    <WhatsAppButton />
                  </div>
                  <p className="flex items-start gap-2 pt-2 text-xs text-cream-50/60">
                    <MapPin className="mt-0.5 size-4 shrink-0 text-gold-300" /> {business.address.full}
                  </p>
                </div>
              </DialogPrimitive.Content>
            </DialogPrimitive.Portal>
          </DialogPrimitive.Root>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  const notConfigured = useNotConfigured();
  const social = (name: string) =>
    notConfigured({
      title: `${name} — à configurer`,
      detail: `Aucun compte ${name} n'est indiqué sur la fiche Google. Ajoutez le lien pour l'afficher ici et dans l'en-tête.`,
    });
  return (
    <footer className="relative overflow-hidden bg-emerald-950 pb-28 pt-20 text-cream-50 lg:pb-10">
      <div className="grain absolute inset-0" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Logo light />
            <p className="mt-6 max-w-sm text-sm leading-relaxed text-cream-50/65">
              Salon de beauté à Delmas 40B, Port-au-Prince : coiffure, tresses & locs, ongles, regard, maquillage et
              services mariée.
            </p>
            <div className="mt-6 flex gap-2">
              {[
                { n: "Instagram", I: Instagram, url: business.social.instagram },
                { n: "Facebook", I: Facebook, url: business.social.facebook },
              ].map(({ n, I, url }) =>
                url ? (
                  <a key={n} href={url} target="_blank" rel="noopener noreferrer" aria-label={n} className="rounded-full p-3 ring-1 ring-white/15 transition hover:bg-white/10">
                    <I className="size-4" />
                  </a>
                ) : (
                  <button key={n} type="button" onClick={() => social(n)} aria-label={`${n} (à configurer)`} className="cursor-pointer rounded-full p-3 ring-1 ring-white/15 transition hover:bg-white/10">
                    <I className="size-4" />
                  </button>
                )
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-gold-300">Pages</h3>
            <ul className="mt-5 space-y-3 text-sm">
              {NAV.map((n) => (
                <li key={n.to}><Link to={n.to} className="text-cream-50/70 transition hover:text-cream-50">{n.label}</Link></li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-5">
            <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-gold-300">Nous trouver</h3>
            <ul className="mt-5 space-y-4 text-sm text-cream-50/75">
              <li className="flex gap-3"><MapPin className="size-5 shrink-0 text-gold-300" />{business.address.full}</li>
              <li className="flex gap-3"><Clock className="size-5 shrink-0 text-gold-300" />{business.hours.known} <span className="text-cream-50/45">(horaires détaillés à confirmer)</span></li>
            </ul>
            <Button asChild variant="outlineLight" size="sm" className="mt-6">
              <a href={business.google.directionsUrl} target="_blank" rel="noopener noreferrer"><Navigation /> Itinéraire Google Maps</a>
            </Button>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-3 border-t border-white/10 pt-8 text-xs text-cream-50/45 sm:flex-row sm:justify-between">
          <p>Maquette de démonstration réalisée à partir d'informations publiques — non affiliée officiellement à {business.name}.</p>
          <p><Link to="/a-confirmer" className="underline hover:text-cream-50">Informations à confirmer</Link></p>
        </div>
      </div>
    </footer>
  );
}

export function MobileActionBar() {
  return (
    <div className="fixed inset-x-3 bottom-3 z-40 lg:hidden">
      <div className="grid grid-cols-4 gap-1 rounded-2xl bg-emerald-950/95 p-1.5 shadow-2xl ring-1 ring-white/10 backdrop-blur">
        <a href={business.google.directionsUrl} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] font-medium text-cream-50/85 hover:bg-white/5">
          <Navigation className="size-5 text-gold-300" /> Itinéraire
        </a>
        <CallButton variant="ghost" className="h-auto flex-col gap-1 rounded-xl py-2 text-[10px] font-medium text-cream-50/85 hover:bg-white/5 [&_svg]:size-5 [&_svg]:text-gold-300">
          <MobileIcon kind="phone" /> Appeler
        </CallButton>
        <WhatsAppButton variant="ghost" className="h-auto flex-col gap-1 rounded-xl bg-transparent py-2 text-[10px] font-medium text-cream-50/85 shadow-none hover:bg-white/5 [&_svg]:size-5 [&_svg]:text-[#25D366]">
          <MobileIcon kind="wa" /> WhatsApp
        </WhatsAppButton>
        <Link to="/contact" className="flex flex-col items-center gap-1 rounded-xl bg-gold-400 py-2 text-[10px] font-bold text-emerald-950">
          <CalendarHeart className="size-5" /> RDV
        </Link>
      </div>
    </div>
  );
}

function MobileIcon({ kind }: { kind: "phone" | "wa" }) {
  return kind === "phone" ? <Phone /> : <MessageCircle />;
}
