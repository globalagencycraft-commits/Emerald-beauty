import { Toaster } from "sonner";
import { useRoute, Link } from "@/lib/router";
import { ConfigProvider } from "@/components/shared";
import { DemoBanner, Footer, Header, MobileActionBar } from "@/components/layout";
import { Button } from "@/components/ui/button";
import Home from "@/pages/Home";
import Services from "@/pages/Services";
import Gallery from "@/pages/Gallery";
import Reviews from "@/pages/Reviews";
import Contact from "@/pages/Contact";
import ToConfirm from "@/pages/ToConfirm";

function NotFound() {
  return (
    <section className="flex min-h-[70vh] flex-col items-center justify-center bg-emerald-950 px-5 pt-24 text-center text-cream-50">
      <p className="font-display text-8xl text-gold-300">404</p>
      <h1 className="mt-4 font-display text-4xl">Page introuvable</h1>
      <Button asChild variant="gold" className="mt-8"><Link to="/">Retour à l'accueil</Link></Button>
    </section>
  );
}

export default function App() {
  const { path, params } = useRoute();

  let page;
  switch (path) {
    case "/": page = <Home />; break;
    case "/prestations": page = <Services params={params} />; break;
    case "/galerie": page = <Gallery />; break;
    case "/avis": page = <Reviews />; break;
    case "/contact": page = <Contact params={params} />; break;
    case "/a-confirmer": page = <ToConfirm />; break;
    default: page = <NotFound />;
  }

  return (
    <ConfigProvider>
      <a href="#contenu" onClick={(e) => { e.preventDefault(); document.getElementById("contenu")?.focus(); }} className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-gold-400 focus:px-4 focus:py-2 focus:text-emerald-950">
        Aller au contenu
      </a>
      <DemoBanner />
      <Header path={path} />
      <main id="contenu" tabIndex={-1} className="outline-none" key={path}>
        {page}
      </main>
      <Footer />
      <MobileActionBar />
      <Toaster position="top-center" richColors closeButton />
    </ConfigProvider>
  );
}
